package com.ribro.crosshair.mod;

public class ExampleMod {
    public static final String MOD_ID = "ribrocrosshairmod";

    public static void init() {
        System.out.println("Hello World!");
    }
}
