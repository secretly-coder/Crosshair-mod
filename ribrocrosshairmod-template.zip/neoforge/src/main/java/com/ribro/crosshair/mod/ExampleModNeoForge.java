package com.ribro.crosshair.mod;

import net.neoforged.fml.common.Mod;

@Mod(ExampleMod.MOD_ID)
public class ExampleModNeoForge {
    public ExampleModNeoForge() {
        ExampleMod.init();
    }
}
